import React from "react";
import Knuffel from "./Knuffel.jsx";

export default function App() {
  return <Knuffel />;
}